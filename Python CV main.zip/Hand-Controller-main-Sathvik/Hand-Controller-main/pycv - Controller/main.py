import CarGameController as CarGame
import pointerGameController as Pointer
import leftHolderMouseButton as Spliter


# CarGame.game() # 2 handtracker
# Pointer.game() # 2 finger for click and 1 finger for changing position
Spliter.game()  # 5 finger to unpress and 1 finger to start pressing
